﻿namespace BeautyTrack
{
    partial class OilySkinPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlOilySkin = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControlOilySkin.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlOilySkin
            // 
            this.tabControlOilySkin.Controls.Add(this.tabPage1);
            this.tabControlOilySkin.Controls.Add(this.tabPage2);
            this.tabControlOilySkin.Controls.Add(this.tabPage3);
            this.tabControlOilySkin.Controls.Add(this.tabPage4);
            this.tabControlOilySkin.Controls.Add(this.tabPage5);
            this.tabControlOilySkin.Location = new System.Drawing.Point(-5, -1);
            this.tabControlOilySkin.Name = "tabControlOilySkin";
            this.tabControlOilySkin.SelectedIndex = 0;
            this.tabControlOilySkin.Size = new System.Drawing.Size(1096, 563);
            this.tabControlOilySkin.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(993, 518);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Moisturizer";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(993, 518);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Sunscreen";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(993, 518);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Serums";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(993, 518);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Face Mask";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = global::BeautyTrack.Properties.Resources.Berminyak___Facewash;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1088, 534);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Face Wash";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // OilySkinPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1086, 556);
            this.Controls.Add(this.tabControlOilySkin);
            this.Name = "OilySkinPage";
            this.Text = "OilySkinPage";
            this.tabControlOilySkin.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlOilySkin;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
    }
}