﻿namespace BeautyTrack
{
    partial class ChooseLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonLoginUser = new System.Windows.Forms.Button();
            this.buttonLoginAdmin = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::BeautyTrack.Properties.Resources._0;
            this.pictureBox1.Location = new System.Drawing.Point(-68, -14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1107, 586);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // buttonLoginUser
            // 
            this.buttonLoginUser.BackColor = System.Drawing.Color.MediumPurple;
            this.buttonLoginUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLoginUser.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonLoginUser.Location = new System.Drawing.Point(92, 360);
            this.buttonLoginUser.Name = "buttonLoginUser";
            this.buttonLoginUser.Size = new System.Drawing.Size(123, 32);
            this.buttonLoginUser.TabIndex = 1;
            this.buttonLoginUser.Text = "Login User";
            this.buttonLoginUser.UseVisualStyleBackColor = false;
            this.buttonLoginUser.Click += new System.EventHandler(this.buttonLoginUser_Click);
            // 
            // buttonLoginAdmin
            // 
            this.buttonLoginAdmin.BackColor = System.Drawing.Color.MediumPurple;
            this.buttonLoginAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLoginAdmin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonLoginAdmin.Location = new System.Drawing.Point(239, 360);
            this.buttonLoginAdmin.Name = "buttonLoginAdmin";
            this.buttonLoginAdmin.Size = new System.Drawing.Size(123, 32);
            this.buttonLoginAdmin.TabIndex = 2;
            this.buttonLoginAdmin.Text = "Login Admin";
            this.buttonLoginAdmin.UseVisualStyleBackColor = false;
            // 
            // ChooseLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 566);
            this.Controls.Add(this.buttonLoginAdmin);
            this.Controls.Add(this.buttonLoginUser);
            this.Controls.Add(this.pictureBox1);
            this.Name = "ChooseLogin";
            this.Text = "ChooseLogin";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonLoginUser;
        private System.Windows.Forms.Button buttonLoginAdmin;
    }
}